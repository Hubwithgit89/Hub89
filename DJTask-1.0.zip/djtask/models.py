from django.db import models
from django.contrib.auth.models import User

class Task(models.Model):
    name = models.CharField(maxlength=255)
    description = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    hours = models.IntegerField()
    owner = models.ForeignKey(User)
    paid = models.BooleanField(default=False)
    
    def __str__(self): return self.name

    class Admin:
        fields = (
            ('Task Info',{'fields':('owner','name','description')}),
            ('Time & Pay',{'fields':('created','updated','hours','paid')}),            
        )
            
        list_display = ('name', 'description', 'owner', 'created','updated','hours','paid')
        list_filter = ('created', 'updated', 'paid', 'owner')
        search_fields = ('name', 'description')

class Project(models.Model):
    name = models.CharField(maxlength=255)
    created = models.DateTimeField(auto_now_add=True)
    tasks = models.ManyToManyField(Task)
    due = models.DateTimeField(blank=True, default=None)
    
    class Admin:
        pass

    def __str__(self): return self.name

class UserPay(models.Model):
    user = models.ForeignKey(User, unique=True)
    pay = models.IntegerField()
    
    class Admin:
        pass
    
    def __str__(self): return self.user.username