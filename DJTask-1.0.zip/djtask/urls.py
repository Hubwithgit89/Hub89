from django.conf.urls.defaults import *



urlpatterns = patterns('project.djtask.views',
    (r'^$', 'index'),
    (r'^login/$', 'login'),
    (r'^logout/$','logout'),
    (r'^add/$', 'add'),
    (r'^paysheet/$', 'paysheet'),
    (r'^view/(?P<task_id>\w+)/$', 'view'),
    (r'^edit/(?P<task_id>\w+)/$', 'edit'),
)
