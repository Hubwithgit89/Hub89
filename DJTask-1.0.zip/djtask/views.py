from project.djtask.models import Task,UserPay
from django.contrib.auth.models import User
from django.shortcuts import render_to_response
from django.http import HttpResponseRedirect
from fckeditor import FCKeditor
NS = {}


def buildns(title, req):
    NS['form'] = req.POST
    NS['session'] = req.session
    NS['title'] = title[0].upper()+title[1:]
    if 'AUTH' in req.session.keys():
        NS['user'] = req.session['AUTH']
    else:
        NS['user'] = None
    return 'djtask/%s.html'%title
    
    

def index(request):
    if not 'AUTH' in request.session.keys():
        return login(request)
    NS['tasks'] = Task.objects.filter(owner=request.session['AUTH'])
    return render_to_response(buildns('list',request), NS)  

def logout(request):
    try:
        del request.session['AUTH']
    except KeyError:
        pass
    return login(request)

def login(request):
    NS['title'] = 'Login'
    POST = request.POST
    if POST.has_key('username'):
        try:
            user = User.objects.get(username=POST['username'])
        except:
            NS['msg'] = 'Login error, try again'
            return render_to_response('pay/login.html',NS)
        if user.check_password(POST['password']):
            request.session['AUTH'] = user
            return HttpResponseRedirect('/djtask/')
        else:
            NS['msg'] = 'Login error, try again'
            return render_to_response(buildns('login',request), NS)            
    else:
        return render_to_response(buildns('login',request), NS)



def edit(request, task_id):
    if not 'AUTH' in request.session.keys():
        return login(request)
    POST = request.POST
    T = Task.objects.get(id=task_id)
    if POST.has_key('description'):
        T.description = POST['description']
        T.hours = POST['hours']
        if POST.has_key('paid'):
            T.paid = True
        else:
            T.paid = False
        T.save()
    NS['task'] = T
    NS['description'] = FCKeditor('description').Create(T.description)
    return render_to_response(buildns('edit',request), NS)

def add(request):
    if not 'AUTH' in request.session.keys():
        return login(request)
    NS['title'] = 'Add'
    POST = request.POST
    if POST.has_key('name'):
        T = Task(
            name = POST['name'], 
            description = POST['description'],
            hours = request.POST['hours'],
            owner = request.session['AUTH'],
            paid = False
        )
        T.save()
        NS['msg'] = 'Task %s created'%T.name
    NS['description'] = FCKeditor('description').Create()
    return render_to_response(buildns('add',request),NS)


def view(request, task_id):
    if not 'AUTH' in request.session.keys():
        return login(request)
    T = Task.objects.get(id=task_id)
    NS['title'] = T.name
    NS['description'] = T.description
    return render_to_response(buildns('view',request), NS)

def paysheet(request):
    if not 'AUTH' in request.session.keys():
        return login(request)
    user = request.session['AUTH']
    POST = request.POST
    T = []
    NS['title'] = 'Paysheet'
    NS['form'] = POST
    NS['index'] = 'Paysheet'
    NS['MODEL'] = ['Name','Created','Hours','Paid']
    NS['user'] = user
    payfactor = UserPay.objects.get(user=request.session['AUTH']).pay
    tasks = Task.objects.filter(owner=request.session['AUTH'])
    paidhours = 0
    unpaidhours = 0;
    fkeys = map(int,POST.keys())
    for k in fkeys:
        T = Task.objects.get(id=k)
        T.paid = True
        T.save()
    for t in tasks:
        if t.paid:
            paidhours += t.hours
        else:
            unpaidhours += t.hours
    NS['tasks'] = tasks
    NS['paid'] = paidhours * payfactor
    NS['unpaid'] = unpaidhours * payfactor
    NS['paidhours'] = paidhours
    NS['unpaidhours'] = unpaidhours
    return render_to_response(buildns('paysheet',request), NS)
