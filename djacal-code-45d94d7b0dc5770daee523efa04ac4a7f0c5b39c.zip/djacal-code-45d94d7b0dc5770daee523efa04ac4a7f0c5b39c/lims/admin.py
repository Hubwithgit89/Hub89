from django.contrib import admin
from djacal.lims.models import *

class InstitutionAdmin( admin.ModelAdmin ):
	pass

class PersonAdmin( admin.ModelAdmin ):
	pass

class ItemAdmin( admin.ModelAdmin ):
	""" Defines how the admin interface deals with the L{Item} object. """
	# When list_display includes additional properties, only those items that
	# have these properties defined are actually displayed.
	# list_display = ( 'name', 'maker', 'maker_code' )
	filter_horizontal = ( 'tags', )


admin.site.register( Institution, InstitutionAdmin )
admin.site.register( Person, PersonAdmin )
admin.site.register( Budget )
admin.site.register( Room )
admin.site.register( StoragePlace )
admin.site.register( Place )
admin.site.register( Box )
admin.site.register( Item, ItemAdmin )
admin.site.register( Order )
admin.site.register( Sop )
admin.site.register( Project )
admin.site.register( Experiment )
admin.site.register( SampleType )
admin.site.register( Sample )
admin.site.register( Species )
admin.site.register( Strain )
# admin.site.register( Animal )
admin.site.register( Tag )
admin.site.register( Inventory )
admin.site.register( Comment )
admin.site.register( UserProfile )
