""" Defines the non-generic views of Djacal.
"""

from django.shortcuts import render
# from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView, UpdateView, DetailView, \
	CreateView, RedirectView
from django.forms import ModelForm
from django.core.urlresolvers import reverse
from django.contrib.auth.models import User
from lims.models import Order, UserProfile
import datetime

# from https://code.djangoproject.com/ticket/5925
from django.utils.functional import lazy
reverse_lazy = lazy( reverse, str )

#class GenericDetailView( DetailView ):
#	""" Subclassing the L{DetailView} generic class-based view, this view can
#	display all the fields of a model class as a table or as HTML paragraphs.
#	"""
#	template_name = 'lims/generic_detail.html'
#
#	def get_context_data( self, **kwargs ):
#		""" Overriding the parent method, L{get_context_data} adds the field
#		names and field values from the requested object to the template kwargs.
#		"""
#		context = DetailView.get_context_data( self, **kwargs )
#		from django.db import models
#		fields = self.object._meta.fields
#		contextfields = []
#		for field in fields:
#			contextfields.append( ( field.verbose_name, field.to_python( field ) ) )
#		context['dict'] = contextfields
#		return context

class MsgUpdateView( UpdateView ):
	""" Derived from L{UpdateView}, this class-based view will re-render the
	form when the data has been successfully saved to the database; it will 
	include a context variable I{success}=True to enable the template displaying
	the form to show a success message."""
	def form_valid( self, form ):
		return self.render_to_response( self.get_context_data( form=form, success=True ) )

class UpdateViewExt ( UpdateView ):
	"""
	This class-based view extends L{UpdateView} to include support for
	a named URL whose reverse lookup is deferred until it is needed. In addition,
	when redirecting to the named success URL, an additional context variable
	I{success}=True is passed.
	"""
	named_success_url = None

	def post( self, request, *args, **kwargs ):
		"""
		Checks if a named_success_url parameter is transmitted with the POST data.
		If so, it will be used to redirect the browser if the form is valid.

		Templates can include a hidden field to inform the view class about the
		appropriate success URL. Thus, a single view can be used in different
		contexts and redirect to different pages upon success.
		
		Hidden field to include in the HTML form:
			<input type="hidden" name="named_success_url" value="my-url-name" />		
		"""
		if 'named_success_url' in self.request.POST:
			self.named_success_url = self.request.POST['named_success_url']
			# We cannot remove the named_success_url parameter from the POST
			# data as the POST dictionary is immutable in Django.
			# It doesn't hurt to keep it in the POST data though (tried it).
			# del self.request.POST['named_success_url']
		return super( UpdateView, self ).post( request, *args, **kwargs )

	def get_success_url( self ):
		if self.named_success_url:
			return reverse( self.named_success_url )
		else:
			return UpdateView.get_success_url( self )

class OrderCentralView( TemplateView ):
	"""
	Provides a list of pending orders (with undefined received dates) and
	a list of orders that have not yet been dispatched (with dispatched field
	set to False).
	"""
	template_name = 'order-central.html'

	def get_context_data( self, **kwargs ):
		ctx = TemplateView.get_context_data( self, **kwargs )
		ctx['orders_not_dispatched'] = \
			Order.objects.filter( dispatched=False ).order_by( '-date_ordered' )
		ctx['pending_orders'] = \
			Order.objects.filter( dispatched=True ). \
			filter( date_received__isnull=True ) \
			.order_by( '-date_ordered' )
		ctx['recent_orders'] = \
			Order.objects.filter( dispatched__isnull=False ). \
			filter( date_received__isnull=False ) \
			.order_by( '-date_received', '-date_ordered' )[:10]
		return ctx

class NewOrderForm( ModelForm ):
	class Meta:
		model = Order
		fields = ( 'count', 'description', 'budget' )


class NewOrderView( UpdateViewExt ):
	"""
	Creates a new instance of an L{Order} object and seeds it with information
	from an L{Item} whose primary key (pk) is passed in.
	
	Pass an 'item_pk' kwarg to the constructor rather than to the as_view function,
	like so:
		NewOrderView(item_pk='123').as_view()
		
	The View constructor takes all kwargs and turns them into class properties.
	
	Note that this class is derived from L{UpdateView} even though it serves
	to I{create} an order; however, we need L{UpdateView} to use the newly
	created L{Order} object.
	"""

	form_class = NewOrderForm

	def get_object( self, queryset=None ):
		"""
		Create a new instance of an L{Order} object.
		
		Since NewOrderView should be called with the primary key of a specific
		L{Item}. The method copies the values of package_size, package_unit,
		and package_cost from L{Item} to L{Order}, as this information may
		change over time, but needs to be 'frozen' for the order on hand.
		
		@todo: Automagically link the current user to this L{Order}. 
		"""
		self.object = Order()
		self.object.user_id = self.request.user.pk
		self.object.item_id = self.kwargs['item_pk']
		self.object.package_unit_ordered = self.object.item.package_unit
		self.object.package_size_ordered = self.object.item.package_size
		self.object.package_cost = self.object.item.package_cost
		return self.object

class DispatchOrdersView( TemplateView ):
	"""
	This view marks all orders as dispatched, then shows a template which can
	inform the user that all orders have been marked as dispatched.
	"""
	template_name = 'lims/orders-dispatched.html'
#	url = reverse_lazy( 'djacal-order-central' )

	def get( self, request, *args, **kwargs ):
		Order.objects.filter( dispatched=False ).update( dispatched=True )
		return TemplateView.get( self, request, *args, **kwargs )

class ItemReceivedView( TemplateView ):
	"""
	This view marks an ordered item as received, then shows a template which
	can inform the user that all orders have been marked as dispatched.
	"""
	template_name = 'lims/item-received.html'

	def get( self, request, *args, **kwargs ):
		o = Order.objects.get( pk=self.kwargs['pk'] )
		o.date_received = datetime.datetime.today()
		o.save()
		return TemplateView.get( self, request, *args, **kwargs )

class AllItemsReceivedView( TemplateView ):
	"""
	Marks all ordered items as received.
	"""
#	url = reverse_lazy( 'djacal-order-central' )
	template_name = 'lims/all-items-received.html'

	def get( self, request, *args, **kwargs ):
		Order.objects.filter( dispatched=True ).filter( date_received=None ) \
			.update( date_received=datetime.datetime.today() )
		return TemplateView.get( self, request, *args, **kwargs )

class ProfileView( UpdateView ):
	def get_object( self, queryset=None ):
		# Look up the user profile by the logged in user's primary key (id).
		o = User.objects.get( pk=self.request.user.pk ).userprofile
		return o
