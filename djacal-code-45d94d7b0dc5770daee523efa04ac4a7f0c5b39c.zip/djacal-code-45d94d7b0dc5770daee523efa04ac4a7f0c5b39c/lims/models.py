""" Defines the database model for Djacal. This is the place where all
abstractions are made.
"""

from django.db import models
from django.contrib.auth.models import User
import datetime

# Create your models here.

class Tag( models.Model ):
	""" Tags are simple textual labels that may be 'attached' to all kinds
	of objects. """
	name = models.CharField( max_length=30 )
	def __unicode__( self ):
		return self.name

class Commentable( models.Model ):
	""" An abstract base model that a L{Note} instance can use as a foreign key.
	
	Using Commentable as a base for other classes enables us to use a common
	L{Note} class instead of having to defined specialized L{Note} classes for
	every model that is commentable."""
	# class Meta:
		# abstract = True


class Comment( models.Model ):
	""" Comments may be attached to any instance of a model that is derived
	from L{Commentable}."""
	commented_object = models.ForeignKey( Commentable )
	text = models.TextField()
	user = models.ForeignKey( User )
	date_stamp = models.DateTimeField( auto_now_add=True )
	def __unicode__( self ):
		return 'Comment; primary key: {}'.format( self.pk )

class Institution( Commentable ):
	""" A company, academic institute, or any other organisation. """
	name = models.CharField( max_length=50, unique=True )
	description = models.CharField( max_length=100, blank=True , null=True )
	email = models.EmailField( max_length=60, blank=True, null=True )
	url = models.URLField( max_length=200, blank=True , null=True )
	street = models.CharField( max_length=50, blank=True , null=True )
	zip_code = models.CharField( max_length=15 , blank=True, null=True )
	place = models.CharField( max_length=30, blank=True , null=True )
	state_or_province = models.CharField( max_length=50, blank=True , null=True )
	country = models.CharField( max_length=30 , blank=True, null=True )
	tel = models.CharField( max_length=20, blank=True, null=True )
	fax = models.CharField( max_length=20, blank=True, null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Person( Commentable ):
	""" A basic person class for any human being involved in the laboratory
	business.
	"""
	title = models.CharField( max_length=15, blank=True, null=True )
	first_name = models.CharField( max_length=50 )
	middle_initial = models.CharField( max_length=3 , blank=True , null=True )
	last_name = models.CharField( max_length=50 )
	institution = models.ForeignKey( Institution, blank=True , null=True )
	department = models.CharField( max_length=60, blank=True , null=True )
	division = models.CharField( max_length=60, blank=True , null=True )
	tel_private = models.CharField( max_length=20, blank=True, null=True )
	tel_business = models.CharField( max_length=20, blank=True , null=True )
	tel_cell = models.CharField( max_length=20, blank=True, null=True )
	fax_private = models.CharField( max_length=20 , blank=True, null=True )
	fax_business = models.CharField( max_length=20 , blank=True, null=True )
	email = models.EmailField( max_length=60 , blank=True , null=True )
	url = models.URLField( max_length=200, blank=True , null=True )
	street = models.CharField( max_length=60 , blank=True, null=True )
	zip_code = models.CharField( max_length=15, blank=True , null=True )
	place = models.CharField( max_length=30 , blank=True , null=True )
	state_or_province = models.CharField( max_length=50, blank=True , null=True )
	country = models.CharField( max_length=30 , blank=True , null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return '{} {}'.format( self.last_name, self.first_name )
	class Meta:
		ordering = ['last_name', 'first_name', 'middle_initial', 'title']

class UserProfile( models.Model ):
	""" A user profile is associated with a Django user and stores additional
	information such as language preference. """
	personal_info = models.OneToOneField( Person ) #< Associate the profile with a person
	language = models.CharField( max_length=5, blank=True , null=True )
	user = models.OneToOneField( User )
	def __unicode__( self ):
		return 'User profile of {} ({})'.format( self.personal_info, self.user )


class Budget( Commentable ):
	""" Any budget available to the lab, e.g. from a grant."""
	name = models.CharField( max_length=30 , unique=True )
	description = models.CharField( max_length=50, blank=True , null=True )
	funding_source = models.ManyToManyField( Institution )
	unlimited = models.BooleanField() #< If True, this Budget is assumed to have unlimited funds.
	total_funds = models.PositiveIntegerField( blank=True , null=True )
	start_date = models.DateField( blank=True , null=True )
	end_date = models.DateField( blank=True , null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		s = '{} ({})'
		if self.unlimited:
			return s.format( self.name, 'unlimited' )
		else:
			return s.format( self.name, self.total_funds )
	class Meta:
		ordering = ['name']
		permissions = ( 
				( 'has_budget_rights', 'Can view and change budgets and related information.' ),
			)


class Room( Commentable ):
	""" A real-world room in the building. """
	name = models.CharField( max_length=30, unique=True )
	description = models.CharField( max_length=50, blank=True, null=True )
	building = models.CharField( max_length=30, blank=True , null=True )
	user = models.ForeignKey( User, blank=True, null=True ) #< A user in charge of this room
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class StoragePlace( Commentable ):
	""" An abstract class for places to store stuff.
	
	Since a L{Place} may or may not have L{Box}es in it, we need to have a way
	to 'store' an L{Item} in a L{Place} or in a L{Box} which is itself stored
	in a L{Place}.
	"""
#	class Meta:
#		abstract = True

class Place( StoragePlace ):
	""" A place may be any place in the lab: a shelf, a fridge, etc. """
	name = models.CharField( max_length=30 )
	description = models.CharField( max_length=50, blank=True, null=True )
	room = models.ForeignKey( Room )
	temperature = models.PositiveIntegerField( blank=True , null=True )
	user = models.ForeignKey( User, related_name='places_managed', blank=True, null=True ) #< A User in charge of this place
	num_levels = models.PositiveIntegerField( blank=True , null=True )
	num_slots = models.PositiveIntegerField( blank=True, null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Box( StoragePlace ):
	""" A box is a container for L{Item}s and is stored in a certain L{Place}.
	"""
	name = models.CharField( max_length=30 )
	description = models.CharField( max_length=50, blank=True, null=True )
	place = models.ForeignKey( Place )
	num_slots = models.PositiveIntegerField( blank=True , null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return '{} ({})'.format( self.name, place.name )
	class Meta:
		ordering = ['name']

class Item( Commentable ):
	""" Any item that can be ordered and stored.
	
	This may be a reagent, or piece of equipment. """
	name = models.CharField( max_length=100, unique=True )
	description = models.CharField( max_length=250 , blank=True , null=True )
	internal_code = models.CharField( max_length=30, blank=True, null=True )
	maker = models.ForeignKey( Institution, related_name="items_made" )
	maker_code = models.CharField( max_length=30 )
	vendor = models.ForeignKey( Institution, blank=True, null=True, related_name="items_sold" )
	vendor_code = models.CharField( max_length=30 , blank=True, null=True )
	package_size = models.FloatField( blank=True, null=True )
	package_unit = models.CharField( max_length=30 , blank=True, null=True )
	package_cost = models.FloatField( blank=True , null=True )
	url = models.URLField( max_length=250, blank=True, null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Inventory( Commentable ):
	""" The Inventory links L{Item}s to storage L{Place}s (L{Box}es, L{Room}s).
	"""
	item = models.ForeignKey( Item )
	location = models.ForeignKey( StoragePlace )
	user = models.ForeignKey( User, blank=True, null=True )
	def __unicode__( self ):
		return "{} stored in {}".format( self.item, self.location )

class Order( models.Model ):
	""" An order of an item.
	
	Orders may be budgeted or not. If not designated 'budgeted' when the order
	was placed, the principal administrator (or another person in charge of 
	the budgets) may assign a budget in retrospect, making it possible to place
	order without knowing the budget.
	
	When an order is placed, the current package size and cost are copied over
	from the L{Item} instance, in case the package size and/or cost change over
	time.
	
	Orders can be marked as 'dispatched' so as to keep track of which orders
	have not been printed yet. As of 2011, many laboratories in academia do not
	yet have an	integrated ordering system yet, so that orders need to be 
	printed on paper to be processed.
	"""
	item = models.ForeignKey( Item )
	count = models.FloatField()
	description = models.CharField( max_length=100, blank=True, null=True )
	date_ordered = models.DateField( auto_now_add=True )
	package_size_ordered = models.FloatField( blank=True, null=True )
	package_unit_ordered = models.CharField( max_length=30 , blank=True, null=True )
	package_cost = models.FloatField( blank=True, null=True )
	date_received = models.DateField( blank=True , null=True )
	budget = models.ForeignKey( Budget, blank=True , null=True )
	user = models.ForeignKey( User ) #< The user who made this order
	dispatched = models.BooleanField()
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def total_cost( self ):
		"""
		Returns the product of the amount of packages ordered and the cost
		of one package.
		"""
		return self.count * self.package_cost

	def __unicode( self ):
		return 'Order of {}'.format( self.item.name )
	class Meta:
		ordering = ['-date_ordered']


class Sop( Commentable ):
	""" Standard operating procedures (SOP) may be experimental protocols, 
	buffer recipies or any other procedure that needs to be standardized.
	"""
	name = models.CharField( max_length=30, unique=True )
	user = models.ForeignKey( User ) #< The user who wrote this SOP
	based_on_sop = models.ForeignKey( 'self' , blank=True, null=True )
	description = models.TextField( max_length=50 )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Project( Commentable ):
	""" A scientific project. """
	name = models.CharField( max_length=30 )
	description = models.CharField( max_length=50, blank=True , null=True )
	principal_investigator = models.ForeignKey( User, related_name="pi_of_project" )
	users = models.ManyToManyField( User, blank=True, null=True ) #< Other Users on the project
	collaborators = models.ManyToManyField( Person, related_name='collaborating_on', blank=True, null=True )
	grant_id = models.CharField( max_length=30, blank=True , null=True )
	budgets = models.ManyToManyField( Budget, blank=True , null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Experiment ( Commentable ):
	""" An experiment associated with a certain project.
	
	An Experiment must have a L{User} associated with it.
	
	An Experiment may have collaborators (instances of L{Person}) associated
	with it.
	"""
	name = models.CharField( max_length=30 )
	aim = models.CharField( max_length=50 )
	date = models.DateField( auto_now_add=True )
	notes = models.TextField( blank=True )
	project = models.ForeignKey( Project )
	sops = models.ManyToManyField( Sop, blank=True , null=True )
	users = models.ManyToManyField( User )
	collaborators = models.ManyToManyField( Person, blank=True, null=True )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode__( self ):
		return self.name
	class Meta:
		ordering = ['-date']

class SampleType ( models.Model ):
	name = models.CharField( max_length=30 ) #< @todo: Make this a choice, maybe?
	def __unicode( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Sample( Commentable ):
	""" A Sample is anything 'real' that comes out of an L{Experiment}.
	
	Samples must have a name and a count of the number of vials; they must be
	associated with an L{Experiment} as well as a L{SampleType} and a storage
	L{StoragePlace}. They may have L{Tag}s attached to them, and are
	L{Commentable}."""
	name = models.CharField( max_length=60 )
	experiment = models.ForeignKey( Experiment )
	sample_type = models.ForeignKey( SampleType )
	num_vials = models.PositiveIntegerField()
	storage_place = models.ForeignKey( StoragePlace ) #< Where the sample is stored
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode( self ):
		return self.name
	class Meta:
		ordering = ['name']

class Species( Commentable ):
	""" An animal species. """
	name = models.CharField( max_length=30 ) #< @todo: Make this a choice, maybe?
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode( self ):
		return self.name
	class Meta:
		verbose_name_plural = 'species'
	class Meta:
		ordering = ['name']

class Strain( Commentable ):
	""" A strain of a L{Species}. """
	name = models.CharField( max_length=30 )
	description = models.CharField( max_length=50, blank=True, null=True )
	species = models.ForeignKey( Species )
	tags = models.ManyToManyField( Tag, blank=True, null=True )
	def __unicode( self ):
		return self.name
	class Meta:
		ordering = ['name']

#class Animal( models.Model ):
#	strain = models.ForeignKey( Strain ) #< This indirectly determines the species as well.
#	tags = models.ManyToManyField( Tag, blank=True, null=True )

