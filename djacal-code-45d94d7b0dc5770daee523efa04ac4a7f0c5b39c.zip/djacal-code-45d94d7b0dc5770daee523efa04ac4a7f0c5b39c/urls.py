""" Maps URL patterns to views. 
"""

from django.conf.urls.defaults import patterns, include, url
from django.views.generic import ListView, DetailView, UpdateView, CreateView, \
	DeleteView, TemplateView
from lims.views import *
from lims.models import Item, Institution, Experiment, Room, Person, Project, \
	Box, Sop, Sample, SampleType, Species, Strain, Tag, Order
from django.contrib.auth.models import User

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
from django.views.generic.base import TemplateView
admin.autodiscover()


urlpatterns = patterns( '',
    url( r'^$',
		TemplateView.as_view( template_name='home.html' ),
		name='djacal-home' ),

    url( r'^about/$',
		TemplateView.as_view( template_name='about.html' ),
		name='djacal-about' ),

	url( r'^profile/$', ProfileView.as_view(), name='user-profile' ),
	url( r'^accounts/login/$', 'django.contrib.auth.views.login' ),
    url( r'^admin/doc/', include( 'django.contrib.admindocs.urls' ) ),
    url( r'^admin/', include( admin.site.urls ) ),
 )

def get_generic_urlpatterns( lims_model ):
	""" Builds urlpatterns for a certain model. 
	
	This function makes it very easy to include url patterns for many different
	model classes.
	
	@param lims_model: The model class for which to build the pattern. (Need to import the class!)
	@rtype: l{patterns()} 
	@return: An instance of patterns() 
	"""
	ns = lims_model.__name__.lower() # in order to define a namespace

	includepatterns = patterns( '',
		url( r'^list/$', ListView.as_view( model=lims_model ), name='list' ),
		url( r'^add/$', CreateView.as_view( model=lims_model ), name='add' ),
		url( r'^show/(?P<pk>\d+)/$', DetailView.as_view( model=lims_model ), name='show' ),
		url( r'^edit/(?P<pk>\d+)/$',
#			lims.views.UpdateViewExt.as_view( model=lims_model, named_success_url='item:list' ), name='edit' ),
			UpdateViewExt.as_view( model=lims_model ), name='edit' ),
		url( r'^delete/(?P<pk>\d+)/$', DeleteView.as_view( model=lims_model ), name='delete' ),
		)

	return patterns( '',
		url( r'^{}/'.format( ns ), include( includepatterns, ns ) ), )


# For certain model classes we include urls to list, edit, add, and delete
# objects. These urls are all defined in one place, i.e. the get_generic_urlpatterns
# function above.

urlpatterns += get_generic_urlpatterns( Item )
urlpatterns += get_generic_urlpatterns( Institution )
urlpatterns += get_generic_urlpatterns( Experiment )
urlpatterns += get_generic_urlpatterns( Room )
urlpatterns += get_generic_urlpatterns( Person )
urlpatterns += get_generic_urlpatterns( Project )
urlpatterns += get_generic_urlpatterns( Box )
urlpatterns += get_generic_urlpatterns( Sop )
urlpatterns += get_generic_urlpatterns( Sample )
urlpatterns += get_generic_urlpatterns( SampleType )
urlpatterns += get_generic_urlpatterns( Species )
urlpatterns += get_generic_urlpatterns( Strain )
urlpatterns += get_generic_urlpatterns( Tag )
urlpatterns += get_generic_urlpatterns( Order )
urlpatterns += get_generic_urlpatterns( User )

urlpatterns += patterns( '',
	url( r'^orders/$',
		OrderCentralView.as_view(), name='djacal-order-central' ),
	url( r'^order/new/$',
		 ListView.as_view( model=Item, template_name='lims/item_list_for_order.html' ),
		 name='djacal-new-order' ),
	url( r'^order/item/(?P<item_pk>\d+)/$', NewOrderView.as_view(), name='djacal-order-item' ),
	url( r'^order/new/create-item/$',
		CreateView.as_view( model=Item ), name='djacal-add-item-and-order' ),
	url( r'^orders/dispatch/$', DispatchOrdersView.as_view(), name='djacal-dispatch-orders' ),
	url( r'^order/receive/(?P<pk>\d+)/$', ItemReceivedView.as_view(), name='djacal-receive-item' ),
	url( r'^orders/received/$', AllItemsReceivedView.as_view(), name="djacal-receive-all" ),
	)
