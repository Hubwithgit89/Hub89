"""
This file is needed as 1.6 only finds tests in files labelled test_*,
and ignores tests/__init__.py.
"""

from south.tests import *
